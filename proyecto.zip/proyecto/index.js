const mongoose = require('mongoose'); // importamos la librería Mongoose
const path = require('path'); // Módulo para rutas absolutas
const express = require('express');
const routes = require('./rutas/usuarioRuta');
const app = express();

// ✅ Middleware para parsear JSON en las peticiones (IMPORTANTE: debe ir antes de usar rutas)
app.use(express.json());

// ✅ Middleware para servir archivos estáticos (tu HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// ✅ Rutas del backend
app.use('/api/usuarios', routes);

//  Conexión a MongoDB Atlas
const mongoURI = "mongodb+srv://MariaBelenGonzalez:12345@cluster0.hqzstyi.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true
};

mongoose.connect(mongoURI, options)
  .then(() => console.log('✅ Conectado a MongoDB Atlas'))
  .catch(err => console.error('❌ Error de conexión:', err));

// Servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor API escuchando en http://localhost:${PORT}`);
});