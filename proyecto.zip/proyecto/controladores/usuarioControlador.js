const Usuario = require('../modelos/usuarioEsquema');
const bcrypt = require('bcrypt'); // 👈 Importamos bcrypt

// Obtener todos los usuarios
exports.obtenerUsuarios = async (req, res) => {
  try {
    const usuarios = await Usuario.find();
    res.json(usuarios);
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};

// Obtener un usuario por ID
exports.obtenerUsuarioid = async (req, res) => {
  try {
    const usuario = await Usuario.findById(req.params.id);
    if (!usuario) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json(usuario);
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};

// Crear un nuevo usuario (con encriptación de la clave)
exports.crearUsuario = async (req, res) => {
  try {
    const datosUsuario = req.body;

    // 🔐 Encriptar la clave antes de guardar
    const salt = await bcrypt.genSalt(10);
    datosUsuario.clave = await bcrypt.hash(datosUsuario.clave, salt);

    const nuevo = new Usuario(datosUsuario);
    const usuarioGuardado = await nuevo.save();

    res.status(201).json(usuarioGuardado); // Puedes ocultar la clave si quieres
  } catch (error) {
    res.status(400).json({ error: 'Error al crear usuario' });
  }
};

// Actualizar un usuario existente
exports.modificarUsuario = async (req, res) => {
  try {
    const datosActualizados = req.body;
    const usuarioActualizado = await Usuario.findByIdAndUpdate(
      req.params.id,
      datosActualizados,
      { new: true }
    );
    if (!usuarioActualizado) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json(usuarioActualizado);
  } catch (error) {
    res.status(400).json({ error: 'Error al actualizar usuario' });
  }
};

// Eliminar un usuario
exports.eliminarUsuario = async (req, res) => {
  try {
    const usuarioEliminado = await Usuario.findByIdAndDelete(req.params.id);
    if (!usuarioEliminado) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json({ message: 'Usuario eliminado' });
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};